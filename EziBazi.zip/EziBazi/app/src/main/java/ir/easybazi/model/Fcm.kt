package ir.easybazi.model

class Fcm {

    var token: String? = null
    var client_key: String? = null
}
